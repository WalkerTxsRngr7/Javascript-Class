// $(document).ready(function () {
//     $("#heading").html("Card Deck")
//     $.getJSON(
//         "https://api.themoviedb.org/3/movie/now_playing?api_key=ab8a8893b0afa6fdc8643b146b27b9f3",
//         function (movie) {
//             $("#deck").html(movie);
//             for (i = 0; i < 3; i++) {
//                 $("div#deck").append('<movie title=movie.results[i].title></movie>');
//             }
//         })

// })